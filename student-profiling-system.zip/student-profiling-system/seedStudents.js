require("dotenv").config();

const mongoose = require("mongoose");
const Student = require("./models/Student");

const students = [
  {
    name: "Santhosh Prakash",
    registerNumber: "24BCS246",
    department: "CSE",
    year: 2,
    section: "D",
    studentCategory: "Hosteller",
    email: "santhosh246@example.com",
    phone: "9876543246",
    gender: "Male",
    academicDetails: {
      cgpa: 8.4,
      arrears: 0,
      tenthMark: 471,
      twelfthMark: 571
    },
    skills: ["Python", "Java", "HTML", "CSS"],
    interests: ["Software Development", "Machine Learning"],
    careerGoal: {
      primary: "Placement",
      description: "Software Engineer"
    },
    achievements: ["Academic Excellence"]
  },
  {
    name: "Ranjith",
    registerNumber: "24BCS221",
    department: "CSE",
    year: 2,
    section: "D",
    studentCategory: "Hosteller",
    email: "ranjith221@example.com",
    phone: "9876543221",
    gender: "Male",
    academicDetails: {
      cgpa: 8.1,
      arrears: 0,
      tenthMark: 450,
      twelfthMark: 550
    },
    skills: ["Java", "C", "DBMS"],
    interests: ["Web Development"],
    careerGoal: {
      primary: "Placement",
      description: "Software Developer"
    },
    achievements: []
  },
  {
    name: "Raguvarman",
    registerNumber: "24BCS217",
    department: "CSE",
    year: 2,
    section: "D",
    studentCategory: "Hosteller",
    email: "raguvarman217@example.com",
    phone: "9876543217",
    gender: "Male",
    academicDetails: {
      cgpa: 8.0,
      arrears: 0,
      tenthMark: 440,
      twelfthMark: 540
    },
    skills: ["Python", "C++"],
    interests: ["Artificial Intelligence"],
    careerGoal: {
      primary: "Higher Studies",
      description: "AI and Machine Learning"
    },
    achievements: []
  },

  ...Array.from({ length: 24 }, (_, i) => {
    const number = 200 + i;
    const registerNumber = `24BCS${number}`;

    return {
      name: `Student ${number}`,
      registerNumber,
      department: "CSE",
      year: 2,
      section: ["A", "B", "C", "D"][i % 4],
      studentCategory: i % 2 === 0 ? "Hosteller" : "Day Scholar",
      email: `student${number}@example.com`,
      phone: `900000${String(number).padStart(4, "0")}`,
      gender: "Male",
      academicDetails: {
        cgpa: Number((7 + (i % 30) / 10).toFixed(2)),
        arrears: i % 3 === 0 ? 1 : 0,
        tenthMark: 400 + (i % 100),
        twelfthMark: 450 + (i % 150)
      },
      skills: ["C", "Python", "Java"],
      interests: ["Software Development"],
      careerGoal: {
        primary: [
          "Placement",
          "Higher Studies",
          "Entrepreneurship",
          "Not Decided"
        ][i % 4],
        description: "Career development"
      },
      achievements: []
    };
  })
];

async function seedStudents() {
  try {
    if (!process.env.MONGODB_URI) {
      throw new Error("MONGODB_URI is missing in .env");
    }

    await mongoose.connect(process.env.MONGODB_URI);

    let inserted = 0;
    let skipped = 0;

    for (const studentData of students) {
      const existing = await Student.findOne({
        registerNumber: studentData.registerNumber
      });

      if (existing) {
        console.log(
          `Skipped existing student: ${studentData.registerNumber}`
        );
        skipped++;
        continue;
      }

      await Student.create(studentData);

      console.log(
        `Added: ${studentData.registerNumber} - ${studentData.name}`
      );

      inserted++;
    }

    console.log("\nSeeding completed.");
    console.log(`Total provided: ${students.length}`);
    console.log(`Inserted: ${inserted}`);
    console.log(`Skipped: ${skipped}`);

  } catch (error) {
    console.error("Seeding error:", error.message);
  } finally {
    await mongoose.disconnect();
  }
}

seedStudents();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const Student = require("./models/Student");
const User = require("./models/User");

// =====================================================
// CHECK MONGODB URI
// =====================================================

if (!process.env.MONGODB_URI) {
    console.error("ERROR: MONGODB_URI is not defined in .env");
    process.exit(1);
}

// =====================================================
// SAMPLE STUDENTS
// =====================================================

const students = [
    {
        name: "Arun Kumar",
        registerNumber: "24BCS101",
        department: "CSE",
        year: 2
    },

    {
        name: "Priya Sharma",
        registerNumber: "24BCS102",
        department: "CSE",
        year: 2
    },

    {
        name: "Karthik Raj",
        registerNumber: "24BCS103",
        department: "CSE",
        year: 2
    }
];

// =====================================================
// SEED DATABASE
// =====================================================

async function seedDatabase() {

    try {

        console.log("Connecting to MongoDB...");

        await mongoose.connect(
            process.env.MONGODB_URI
        );

        console.log("MongoDB connected successfully.");

        // -------------------------------------------------
        // INSERT / UPDATE STUDENTS
        // -------------------------------------------------

        for (const student of students) {

            await Student.findOneAndUpdate(
                {
                    registerNumber:
                        student.registerNumber
                },

                student,

                {
                    upsert: true,
                    new: true,
                    setDefaultsOnInsert: true
                }
            );
        }

        console.log("Student records created/updated.");

        // -------------------------------------------------
        // FACULTY ACCOUNT
        // -------------------------------------------------

        const facultyPassword =
            process.env.FACULTY_PASSWORD;

        if (!facultyPassword) {
            throw new Error(
                "FACULTY_PASSWORD is missing in .env"
            );
        }

        const facultyHash =
            await bcrypt.hash(
                facultyPassword,
                10
            );

        await User.findOneAndUpdate(
            {
                username:
                    process.env.FACULTY_USERNAME ||
                    "faculty"
            },

            {
                username:
                    process.env.FACULTY_USERNAME ||
                    "faculty",

                passwordHash:
                    facultyHash,

                role: "faculty",

                active: true
            },

            {
                upsert: true,
                new: true,
                setDefaultsOnInsert: true
            }
        );

        // -------------------------------------------------
        // STUDENT ACCOUNTS
        // -------------------------------------------------

        const studentPasswords = {
            "24BCS101":
                process.env.STUDENT_101_PASSWORD,

            "24BCS102":
                process.env.STUDENT_102_PASSWORD,

            "24BCS103":
                process.env.STUDENT_103_PASSWORD
        };

        for (const student of students) {

            const password =
                studentPasswords[
                    student.registerNumber
                ];

            if (!password) {

                throw new Error(
                    `Password missing for ${student.registerNumber}`
                );
            }

            const passwordHash =
                await bcrypt.hash(
                    password,
                    10
                );

            await User.findOneAndUpdate(
                {
                    username:
                        student.registerNumber
                },

                {
                    username:
                        student.registerNumber,

                    passwordHash:
                        passwordHash,

                    role: "student",

                    studentRegisterNumber:
                        student.registerNumber,

                    active: true
                },

                {
                    upsert: true,
                    new: true,
                    setDefaultsOnInsert: true
                }
            );
        }

        console.log("");
        console.log("======================================");
        console.log("DATABASE SEEDING SUCCESSFUL");
        console.log("======================================");

        console.log("");
        console.log("FACULTY LOGIN");
        console.log(
            "Username:",
            process.env.FACULTY_USERNAME || "faculty"
        );
        console.log(
            "Password:",
            process.env.FACULTY_PASSWORD
        );

        console.log("");
        console.log("STUDENT LOGINS");

        console.log(
            "24BCS101 /",
            process.env.STUDENT_101_PASSWORD
        );

        console.log(
            "24BCS102 /",
            process.env.STUDENT_102_PASSWORD
        );

        console.log(
            "24BCS103 /",
            process.env.STUDENT_103_PASSWORD
        );

        console.log("");
        console.log("======================================");

    } catch (error) {

        console.error("");
        console.error("SEEDING FAILED:");
        console.error(error.message);

    } finally {

        await mongoose.connection.close();

        console.log("MongoDB connection closed.");
    }
}

seedDatabase();
require("dotenv").config();

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const User = require("./models/User");

const accounts = [
  ["24BCS246", "Sa7#Kp"],
  ["24BCS221", "Ra4@Wx"],
  ["24BCS217", "Ra9!Ty"],
  ["24BCS200", "St2#Qm"],
  ["24BCS201", "St5@Lp"],
  ["24BCS202", "St8!Rv"],
  ["24BCS203", "St3$Nk"],
  ["24BCS204", "St6&Jx"],
  ["24BCS205", "St9#Bw"],
  ["24BCS206", "St4@Hz"],
  ["24BCS207", "St7!Mc"],
  ["24BCS208", "St1$Yv"],
  ["24BCS209", "St5&Qk"],
  ["24BCS210", "St8@Dx"],
  ["24BCS211", "St2!Wp"],
  ["24BCS212", "St6#Fr"],
  ["24BCS213", "St9$Lm"],
  ["24BCS214", "St3&Xq"],
  ["24BCS215", "St7@Kv"],
  ["24BCS216", "St4!Nz"],
  ["24BCS218", "St1#Ty"],
  ["24BCS219", "St5$Jm"],
  ["24BCS220", "St8&Rp"],
  ["24BCS222", "St2@Qx"],
  ["24BCS223", "St6!Hv"],
  ["24BCS224", "St9@Zn"],
  ["24BCS225", "St3#Fc"]
];

async function seedLogins() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);

    for (const [registerNumber, password] of accounts) {
      const hashedPassword = await bcrypt.hash(password, 10);

      await User.findOneAndUpdate(
        {
          username: registerNumber,
          role: "student"
        },
        {
          $set: {
            username: registerNumber,
            password: hashedPassword,
            role: "student",
            studentRegisterNumber: registerNumber,
            active: true
          }
        },
        {
          upsert: true,
          new: true,
          runValidators: true
        }
      );

      console.log(`Login created: ${registerNumber}`);
    }

    console.log("All 27 student login accounts created.");

  } catch (error) {
    console.error("Error:", error.message);
  } finally {
    await mongoose.disconnect();
  }
}

seedLogins();